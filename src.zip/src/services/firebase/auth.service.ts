// src/services/firebase/auth.service.ts
import {
  signInWithCredential,
  GoogleAuthProvider,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  type FirebaseAuthTypes,
} from '@react-native-firebase/auth';
import {
  doc,
  getDoc,
  setDoc,
  serverTimestamp,
  GeoPoint,
} from '@react-native-firebase/firestore';
import { GoogleSignin } from '@react-native-google-signin/google-signin';
import { authInstance, db } from './index';

export async function googleAuth() {
  await GoogleSignin.hasPlayServices({ showPlayServicesUpdateDialog: true });
  const response = await GoogleSignin.signIn();

  if (response.type !== 'success' || !response.data?.idToken) {
    throw new Error('Google sign-in was cancelled.');
  }

  const credential = GoogleAuthProvider.credential(response.data.idToken);
  const result = await signInWithCredential(authInstance, credential);

  const profileRef = doc(db, 'users', result.user.uid);
  const profileSnap = await getDoc(profileRef);
  return { user: result.user, isNewUser: !profileSnap.exists() };
}

export async function completeRegistration(data: {
  name: string;
  phone: string;
  address: string;
  coords: { latitude: number; longitude: number } | null;
}) {
  const user = authInstance.currentUser;
  if (!user) throw new Error('No signed-in user.');
  await setDoc(
    doc(db, 'users', user.uid),
    {
      displayName: data.name,
      phoneNumber: data.phone || null,
      email: user.email ?? null,
      photoURL: user.photoURL ?? null,
      address: data.address,
      location: data.coords
        ? new GeoPoint(data.coords.latitude, data.coords.longitude)
        : null,
      locationCapturedAt: data.coords ? serverTimestamp() : null,
      tier: 'Standard',
      bookingsCount: 0,
      favoritesCount: 0,
      createdAt: serverTimestamp(),
    },
    { merge: true },
  );
}

export async function signOutUser() {
  await firebaseSignOut(authInstance);
}

export function subscribeToAuthState(
  callback: (user: FirebaseAuthTypes.User | null) => void,
) {
  return onAuthStateChanged(authInstance, callback);
}
