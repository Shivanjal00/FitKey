// src/services/location.service.ts
import Geolocation from '@react-native-community/geolocation';
import { PermissionsAndroid, Platform } from 'react-native';
import { GOOGLE_MAPS_API_KEY } from '../config/env';

// Explicitly use Android's plain LocationManager, not Google Play Services'
// FusedLocationProvider — this is what avoids the exact class of native
// crash we hit with the previous library (a Play Services version mismatch).
try {
  Geolocation.setRNConfiguration({
    skipPermissionRequests: false,
    locationProvider: 'android',
  });
} catch (err) {
  console.warn('Geolocation config failed:', err);
}

export type Coordinates = { latitude: number; longitude: number };

export async function requestLocationPermission(): Promise<boolean> {
  if (Platform.OS !== 'android') return true;
  const granted = await PermissionsAndroid.request(
    PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
    {
      title: 'Location Permission',
      message:
        'FitKey uses your location to show nearby gyms and libraries, and fill in your address automatically.',
      buttonPositive: 'Allow',
      buttonNegative: 'Not now',
    },
  );
  return granted === PermissionsAndroid.RESULTS.GRANTED;
}

export async function forwardGeocode(
  address: string,
): Promise<Coordinates | null> {
  try {
    const url = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(
      address,
    )}&key=${GOOGLE_MAPS_API_KEY}`;
    const res = await fetch(url);
    const json = await res.json();
    if (json.status === 'OK' && json.results?.[0]?.geometry?.location) {
      const { lat, lng } = json.results[0].geometry.location;
      return { latitude: lat, longitude: lng };
    }
    return null;
  } catch {
    return null;
  }
}

export function getCurrentPosition(): Promise<Coordinates> {
  return new Promise((resolve, reject) => {
    Geolocation.getCurrentPosition(
      pos =>
        resolve({
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
        }),
      err => reject(err),
      { enableHighAccuracy: true, timeout: 20000, maximumAge: 60000 },
    );
  });
}

// ---- everything below here is unchanged from before ----

export async function reverseGeocode(
  coords: Coordinates,
): Promise<string | null> {
  try {
    const url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${coords.latitude},${coords.longitude}&key=${GOOGLE_MAPS_API_KEY}`;
    const res = await fetch(url);
    const json = await res.json();
    if (json.status === 'OK' && json.results?.[0]?.formatted_address) {
      return json.results[0].formatted_address as string;
    }
    return null;
  } catch {
    return null;
  }
}

export type DetectAddressResult =
  | { ok: true; address: string | null; location: Coordinates }
  | { ok: false; reason: 'permission-denied' | 'position-failed' };

export async function detectAddress(): Promise<DetectAddressResult> {
  const granted = await requestLocationPermission();
  if (!granted) return { ok: false, reason: 'permission-denied' };
  let location: Coordinates;
  try {
    location = await getCurrentPosition();
  } catch {
    return { ok: false, reason: 'position-failed' };
  }
  const address = await reverseGeocode(location);
  return { ok: true, address, location };
}

function toRad(deg: number) {
  return (deg * Math.PI) / 180;
}

export function calculateDistanceKm(
  from: Coordinates,
  to: Coordinates,
): number {
  const R = 6371;
  const dLat = toRad(to.latitude - from.latitude);
  const dLon = toRad(to.longitude - from.longitude);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(from.latitude)) *
      Math.cos(toRad(to.latitude)) *
      Math.sin(dLon / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

export function formatDistance(km: number): string {
  if (km < 1) return `${Math.round(km * 1000)} m`;
  return `${km.toFixed(1)} km`;
}

export function withComputedDistance<
  T extends { location?: Coordinates | null },
>(
  items: T[],
  userCoords: Coordinates | null,
): (T & { distanceKm: number | null; distance: string })[] {
  return items
    .map(item => {
      if (!userCoords || !item.location) {
        return {
          ...item,
          distanceKm: null,
          distance: (item as any).distance || '—',
        };
      }
      const distanceKm = calculateDistanceKm(userCoords, item.location);
      return { ...item, distanceKm, distance: formatDistance(distanceKm) };
    })
    .sort((a, b) => {
      if (a.distanceKm === null) return 1;
      if (b.distanceKm === null) return -1;
      return a.distanceKm - b.distanceKm;
    });
}
