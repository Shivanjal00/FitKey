// src/store/UserLocationContext.tsx
import {
  createContext,
  useContext,
  useEffect,
  useState,
  ReactNode,
} from 'react';
import {
  requestLocationPermission,
  getCurrentPosition,
  reverseGeocode,
  type Coordinates,
} from '../services/location.service';

type UserLocationContextValue = {
  coords: Coordinates | null;
  address: string | null;
  loading: boolean;
  permissionDenied: boolean;
  refresh: () => void;
};

const UserLocationContext = createContext<UserLocationContextValue | null>(
  null,
);

export function UserLocationProvider({ children }: { children: ReactNode }) {
  const [coords, setCoords] = useState<Coordinates | null>(null);
  const [address, setAddress] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [permissionDenied, setPermissionDenied] = useState(false);

  const fetchLocation = async () => {
    setLoading(true);
    const granted = await requestLocationPermission(); // ← this line is OUTSIDE the try block below
    if (!granted) {
      setPermissionDenied(true);
      setLoading(false);
      return;
    }
    setPermissionDenied(false);
    try {
      const position = await getCurrentPosition();
      setCoords(position);
      setAddress(await reverseGeocode(position));
    } catch (err) {
      console.warn('Could not fetch location:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLocation();
  }, []);

  return (
    <UserLocationContext.Provider
      value={{
        coords,
        address,
        loading,
        permissionDenied,
        refresh: fetchLocation,
      }}
    >
      {children}
    </UserLocationContext.Provider>
  );
}

export function useUserLocation() {
  const ctx = useContext(UserLocationContext);
  if (!ctx)
    throw new Error('useUserLocation must be used within UserLocationProvider');
  return ctx;
}
